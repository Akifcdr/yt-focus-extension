(() => {
  "use strict";

  // ─── State ───────────────────────────────────────────────────────────────
  let enabled = true;
  let overlay = null;

  // ─── Apply / Remove focus mode ───────────────────────────────────────────
  function applyFocusMode() {
    document.body.classList.add("ytfm-active");
    ensureOverlay();
  }

  function removeFocusMode() {
    document.body.classList.remove("ytfm-active");
    removeOverlay();
  }

  // ─── Homepage overlay ────────────────────────────────────────────────────
  function ensureOverlay() {
    if (!isHomePage()) { removeOverlay(); return; }
    if (overlay) return;

    overlay = document.createElement("div");
    overlay.id = "ytfm-home-overlay";
    overlay.innerHTML = `
      <div class="ytfm-icon">🎯</div>
      <p>Focus Mode is ON</p>
      <span>Use the search bar to find what you want</span>
    `;
    document.body.appendChild(overlay);
  }

  function removeOverlay() {
    if (overlay) { overlay.remove(); overlay = null; }
  }

  // ─── Route helpers ───────────────────────────────────────────────────────
  function isHomePage() {
    return location.pathname === "/" || location.pathname === "/feed/trending";
  }

  // ─── Watch for YouTube's SPA navigation ──────────────────────────────────
  function onNavigation() {
    if (!enabled) return;
    // Small delay lets YouTube render its skeleton
    setTimeout(() => {
      applyFocusMode();
      suppressAutoplay();
    }, 300);
  }

  // Suppress autoplay on video pages
  function suppressAutoplay() {
    const setAutoplay = () => {
      const toggle = document.querySelector(".ytp-autonav-toggle-button");
      if (toggle && toggle.getAttribute("aria-checked") === "true") {
        toggle.click();
      }
    };
    setTimeout(setAutoplay, 1500);
  }

  // ─── YouTube SPA uses yt-navigate-finish custom event ────────────────────
  document.addEventListener("yt-navigate-finish", onNavigation);
  document.addEventListener("yt-page-data-updated", onNavigation);

  // ─── Initial load ────────────────────────────────────────────────────────
  chrome.storage.local.get(["ytfm_enabled"], (res) => {
    enabled = res.ytfm_enabled !== false; // default ON
    if (enabled) applyFocusMode();
  });

  // ─── Listen for toggle from popup ────────────────────────────────────────
  chrome.storage.onChanged.addListener((changes) => {
    if ("ytfm_enabled" in changes) {
      enabled = changes.ytfm_enabled.newValue;
      if (enabled) {
        applyFocusMode();
        suppressAutoplay();
      } else {
        removeFocusMode();
      }
    }
  });

  // ─── MutationObserver: re-apply after YouTube re-renders ─────────────────
  // YouTube sometimes re-inserts removed nodes; the CSS class handles hiding
  // but the home overlay may need re-insertion.
  const observer = new MutationObserver(() => {
    if (!enabled) return;
    if (isHomePage() && !overlay) ensureOverlay();
  });

  observer.observe(document.documentElement, { childList: true, subtree: false });
})();
