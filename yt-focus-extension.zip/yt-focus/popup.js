const toggle = document.getElementById("toggle");
const switchEl = document.getElementById("switch");
const label = document.getElementById("toggle-label");
const sub = document.getElementById("toggle-sub");
const badge = document.getElementById("status-badge");
const reloadHint = document.getElementById("reload-hint");

function setUI(enabled) {
  if (enabled) {
    toggle.classList.add("active");
    label.textContent = "Focus Mode";
    sub.textContent = "Distractions are hidden";
    badge.textContent = "ACTIVE";
    badge.classList.add("on");
  } else {
    toggle.classList.remove("active");
    label.textContent = "Focus Mode";
    sub.textContent = "YouTube is unrestricted";
    badge.textContent = "DISABLED";
    badge.classList.remove("on");
  }
}

// Load current state
chrome.storage.local.get(["ytfm_enabled"], (res) => {
  const enabled = res.ytfm_enabled !== false;
  setUI(enabled);
});

// Toggle on click
toggle.addEventListener("click", () => {
  chrome.storage.local.get(["ytfm_enabled"], (res) => {
    const current = res.ytfm_enabled !== false;
    const next = !current;

    chrome.storage.local.set({ ytfm_enabled: next }, () => {
      setUI(next);

      // Show reload hint if the content script might not catch the change
      // (e.g. if user opens popup before navigating to YT)
      reloadHint.classList.add("visible");
      setTimeout(() => reloadHint.classList.remove("visible"), 3000);
    });
  });
});
